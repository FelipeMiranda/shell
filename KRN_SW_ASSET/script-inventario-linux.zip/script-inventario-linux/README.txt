* KRN-SW-ASSET *
Author: Rafael Quirino de Castro
Data: 24/01/2016
################################

Programa de Invent�rio Linux

Basta colocar os servidores desejados na lista servidores.txt

Verificar os comandos que ser�o executados na lista comandos.sh e no caso sera 
necessario digitar usuario e senha para cada host

executar o script script-linux.sh

verificar os resultados dentro do diretorio lista